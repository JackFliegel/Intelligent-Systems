from feedForward import *
from autoEncoder import *

runFeedForward()
runAutoencoder()